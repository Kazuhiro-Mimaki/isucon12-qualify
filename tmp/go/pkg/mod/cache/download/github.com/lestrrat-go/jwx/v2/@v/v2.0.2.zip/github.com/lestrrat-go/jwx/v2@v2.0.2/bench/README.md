# Benchmarks

# Performance Benchmarks

[Measures the performance of github.com/lestrrat-go/jwx/v2](./performance)

# Comparison Benchmarks

[Compares github.com/lestrrat-go/jwx/v2 with other libraries](./comparison)
