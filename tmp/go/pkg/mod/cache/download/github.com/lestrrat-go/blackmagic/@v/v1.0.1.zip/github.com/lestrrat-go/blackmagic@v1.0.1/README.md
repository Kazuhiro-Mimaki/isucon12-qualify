# blackmagic

Reflect-based black magic. YMMV, and use with caution
