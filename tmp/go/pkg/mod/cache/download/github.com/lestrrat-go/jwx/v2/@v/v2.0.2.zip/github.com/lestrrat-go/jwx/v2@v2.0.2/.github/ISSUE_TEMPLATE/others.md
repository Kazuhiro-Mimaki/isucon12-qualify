---
name: 'Other Issues'
about: 'Other types of issues'
title: ''
labels: ''
assignees: ''

---

**Contribution Guidelines**

Before filing an issue, please read the contents of [CONTRIBUTING.md](https://github.com/lestrrat-go/jwx/blob/v2/.github/CONTRIBUTING.md), and follow its instructions.
